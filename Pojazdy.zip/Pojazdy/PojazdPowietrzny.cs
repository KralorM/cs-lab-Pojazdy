﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pojazdy
{
    public class PojazdPowietrzny:Pojazd
    {
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(base.ToString());
            return sb.ToString();
        }

        public PojazdPowietrzny(string name,Silnik silnik = null,Środowisko środowisko = Środowisko.Powietrze):base(name,silnik,środowisko)
        {

        }



    }
}
