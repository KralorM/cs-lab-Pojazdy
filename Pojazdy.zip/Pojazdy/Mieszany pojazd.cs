﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pojazdy
{
    public class Mieszany_pojazd : Pojazd
    {
        //Zmienne
        public int Minprędkość { get; set; }
        public int Maxprędkość { get; set; }
        public int Liczbakol { get; }
        public int Wyporność { get; }
        public Środowisko aktualne_środowisko { get; set; }
        public Środowisko zmienne_środowisko { get; set; }

        public new string domyślna_jednostka;


        public void ZamianaŚrodowiska()
        {
            if (aktualne_środowisko == środowisko)
            {
                aktualne_środowisko = zmienne_środowisko;
                return;
            }
            else
            {
                aktualne_środowisko = środowisko;
            }
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(base.ToString());
            sb.AppendLine($"Liczba kol: {Liczbakol}");
            sb.AppendLine($"Wyporność:{Wyporność}");
            return sb.ToString();
        }


        public Mieszany_pojazd(string name,Środowisko środowisko,Środowisko zmienneśrodowisko,int liczbakolek,int wypornosc,Silnik silnik = null) : base(name, silnik, środowisko)
        {
            this.Wyporność = wypornosc;
            this.Liczbakol = liczbakolek;
            this.zmienne_środowisko = zmienneśrodowisko;


            if (silnik != null && aktualne_środowisko == Środowisko.Woda && zmienne_środowisko == Środowisko.Woda)
            {
                this.silnik.typ_Silnika = Silnik.Typ_silnika.olej;
            }


            if (zmienne_środowisko == Środowisko.Powietrze)
            {
                MaxPredkosc = 200;
                MinPredkosc = 20;
                domyślna_jednostka = "m/s";
            }
            else if (zmienne_środowisko == Środowisko.Ziemia)
            {
                MaxPredkosc = 350;
                MinPredkosc = 1;
                domyślna_jednostka = "km/h";

            }
            else if (zmienne_środowisko == Środowisko.Woda)
            {
                Maxprędkość = 40;
                MinPredkosc = 1;
                domyślna_jednostka = "węzłów";
            }

        }


    }
}
