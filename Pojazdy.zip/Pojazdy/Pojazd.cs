﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pojazdy
{
    public class Pojazd : Pojazd2
    {
        //Zmienne
        private bool Ruch;
        private int prędkość;
        private string name;
        

        public Silnik silnik { get; }
        public int MinPredkosc { get; set; }
        public int MaxPredkosc { get; set; }
        public Środowisko środowisko { get; }

        public string domyślna_jednostka;


        public string wruchu
        {
            get
            {
                if (Ruch)
                {
                    return "Jedzie"; 
                }
                return "Nie jedzie";
            }
            
        }

        public int Prędkość
        {
            get
            {
                return prędkość;
            }
        }

        public void RS()
        {
            if (Ruch)
            {
                Ruch = true;
                Console.WriteLine($"Pojzad {name} porusza się z prędkością {prędkość} {domyślna_jednostka}");
            }
            else
            {
                Ruch = false;
                Console.WriteLine($"Pojazd stanął.");
            }
            Ruch = !Ruch;
        }


        public void Przyśpieszenie(int przyśpieszenie)
        {
            if (Ruch)
            {
                prędkość += przyśpieszenie;

                if (prędkość > MaxPredkosc)
                {
                    prędkość = MaxPredkosc;
                }
                else if (prędkość < MinPredkosc)
                {
                    prędkość = MinPredkosc;
                }
            }
        }


       


        public double Uniwersalna_prędkość()
        {
            return Pojazd2.ObliczaniePrędkości(prędkość,środowisko,Środowisko.Ziemia);
        }


        //Metoda ToString()
        public override string ToString()
        {
            StringBuilder x = new StringBuilder();
            Console.WriteLine("Pojazd informacje ogólne:");
            x.AppendLine($"{name}");
            x.AppendLine($"{prędkość} {domyślna_jednostka}");
            x.AppendLine($"{silnik}");
            x.AppendLine($"{środowisko}");
            x.AppendLine($"{MaxPredkosc} {domyślna_jednostka}");
            x.AppendLine($"{MinPredkosc} {domyślna_jednostka}");
            x.AppendLine($"Obecny stan pojazdu:{wruchu}");
            return x.ToString();
            
        }


        //Pojazd w roznych srodowiskach
        public Pojazd(string name, Silnik silnik = null, Środowisko środowisko = Środowisko.Ziemia)
        {

            this.name = name;
            this.silnik = silnik;
            this.środowisko = środowisko;

            if (środowisko == Środowisko.Ziemia)
            {
                MinPredkosc = 20;
                MaxPredkosc = 350;
                domyślna_jednostka = "km/h";


            }
            else if (środowisko == Środowisko.Woda)
            {
                MinPredkosc = 1;
                MaxPredkosc = 40;
                domyślna_jednostka = "węzły";
            }
            else if (środowisko == Środowisko.Powietrze)
            {
                MinPredkosc = 20;
                MaxPredkosc = 200;
                domyślna_jednostka = "m/s";
            }


        }



    }
    

    

    
}
