﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pojazdy
{
    public class PojazdLadowy : Pojazd
    {
        public int liczba_kol { get; }



        public PojazdLadowy(string name, int liczbaKolek,Silnik silnik = null,Środowisko środowisko = Środowisko.Ziemia) : base(name, silnik, środowisko)
        {
            this.liczba_kol = liczbaKolek;
        }


        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"{base.ToString()}");
            sb.AppendLine($"Liczba kol: {liczba_kol}");
            return sb.ToString();
        }

    }
}
