﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;

namespace Pojazdy
{
    internal interface Pojazd2
    {

        public void RS();
        public double Uniwersalna_prędkość();
        public void Przyśpieszenie(int przyśpieszenie);

        public static int ObliczaniePrędkości(int aktualna_prędkość, Środowisko teraz_środowisko, Środowisko zmienne_środowisko)
        {

            if (teraz_środowisko == Środowisko.Ziemia)
            {
                if (zmienne_środowisko == Środowisko.Powietrze)
                {
                    return (int)(aktualna_prędkość * 0.278);
                }
                else if (zmienne_środowisko == Środowisko.Woda)
                {
                    return (int)(aktualna_prędkość * 0.54);
                }
                else if (zmienne_środowisko == Środowisko.Ziemia)
                {
                    return aktualna_prędkość;
                }
                else
                {
                    return aktualna_prędkość;
                }
            }


            if (teraz_środowisko == Środowisko.Powietrze)
            {
                if (zmienne_środowisko == Środowisko.Powietrze)
                {
                    return (int)(aktualna_prędkość * 1.944);
                }
                else if (zmienne_środowisko == Środowisko.Woda)
                {
                    return (int)aktualna_prędkość;
                }
                else if (zmienne_środowisko == Środowisko.Ziemia)
                {
                    return (int)(aktualna_prędkość * 3.6);
                }
                else
                {
                    return aktualna_prędkość;
                }
            }



            if (teraz_środowisko == Środowisko.Woda)
            {
                if (zmienne_środowisko == Środowisko.Powietrze)
                {
                    return (int)(aktualna_prędkość * 0.514);
                }
                else if (zmienne_środowisko == Środowisko.Woda)
                {
                    return (int)(aktualna_prędkość * 0.54);
                }
                else if (zmienne_środowisko == Środowisko.Ziemia)
                {
                    return aktualna_prędkość;
                }
                else
                {
                    return aktualna_prędkość;
                }
            }

            return aktualna_prędkość;

        }



    }
}
