﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pojazdy
{
    public class Silnik
    {
        public int konie_mechaniczne;
        public Typ_silnika typ_Silnika { get; set; }


        public Silnik(int Konie_mechaniczne,Typ_silnika typ_silnika)
        {
            this.konie_mechaniczne = Konie_mechaniczne;
            this.typ_Silnika = typ_silnika;
        }



        public override string ToString()
        {
            return $"Silnik: Moc:{konie_mechaniczne} Typ:{typ_Silnika}";
        }



        public enum Typ_silnika
        {
            benzyna,
            olej,
            LPG,
            prąd,
            diesel,

        }


    }

    

   
}
