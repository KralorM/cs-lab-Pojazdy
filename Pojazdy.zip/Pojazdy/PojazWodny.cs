﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pojazdy
{
    public class PojazWodny:Pojazd
    {
        public int wyporność { get; }


        public PojazWodny(string name,int Wyporność,Silnik silnik = null,Środowisko środowisko = Środowisko.Woda) : base(name,silnik,środowisko)
        {
            this.wyporność = Wyporność;

            if (silnik.typ_Silnika != Silnik.Typ_silnika.olej)
            {
                throw new Exception("Pojazdy wodne są napędzane tylko olejem");
            }
        }



        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(base.ToString());
            sb.AppendLine($"Wyporność: {wyporność}");
            return sb.ToString();
        }


    }
}
