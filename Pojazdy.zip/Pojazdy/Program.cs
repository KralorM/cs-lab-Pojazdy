﻿
using System;
using System.Collections.Generic;

namespace Pojazdy
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Pojazd> pojazdy = new List<Pojazd>();

            PojazdLadowy hulajnoga = new PojazdLadowy("Hulajnoga",2);

            Silnik silnik_poduszkowca = new Silnik(400,Silnik.Typ_silnika.olej);
            PojazWodny poduszkowiec = new PojazWodny("Poduszkowiec",20,silnik_poduszkowca);

            Silnik silnik_helikoptera = new Silnik(500,Silnik.Typ_silnika.benzyna);
            PojazdPowietrzny helikopter = new PojazdPowietrzny("Helikopter",silnik_helikoptera);

            Silnik silnik_deskorolki = new Silnik(30,Silnik.Typ_silnika.prąd);
            PojazdLadowy deskorola_elektryczna = new PojazdLadowy("Deskorolka elektryczna",4,silnik_deskorolki);

            Silnik silnik_amfibii = new Silnik(100,Silnik.Typ_silnika.olej);
            Mieszany_pojazd amfibia = new Mieszany_pojazd("Amfibia",Środowisko.Woda,Środowisko.Ziemia,10,0,silnik_amfibii);

            Console.WriteLine("Aktualne stany pojazdów:");

            pojazdy.Add(hulajnoga);
            pojazdy.Add(poduszkowiec);
            pojazdy.Add(helikopter);
            pojazdy.Add(deskorola_elektryczna);
            pojazdy.Add(amfibia);


            hulajnoga.RS();
            hulajnoga.Przyśpieszenie(19);

            poduszkowiec.RS();
            poduszkowiec.Przyśpieszenie(400);

            helikopter.RS();
            helikopter.Przyśpieszenie(500);

            deskorola_elektryczna.RS();
            deskorola_elektryczna.Przyśpieszenie(50);

            amfibia.RS();
            amfibia.Przyśpieszenie(600);

            Console.WriteLine("----------------------------------------------------------------");

            foreach (Pojazd pojazd in pojazdy)
            {
                Console.WriteLine(pojazd.ToString());
                Console.WriteLine("-------------------------------------------------------");
            }

            Console.WriteLine("---------------------------------------------------");



          

            Console.WriteLine("Listing only ground vehicles");

            foreach (Pojazd pojazd in pojazdy)
            {
                if (pojazd.środowisko == Środowisko.Ziemia)
                {
                    Console.WriteLine(pojazd.ToString());
                    Console.WriteLine("-----------------------------------------------------");
                }
            }

            Console.WriteLine("Sorting vehicles based on current speed");

            for (int i = 0; i < pojazdy.Count; i++)
            {
                for (int j = 0; j < pojazdy.Count - i - 1; j++)
                {
                    if (pojazdy[j].Uniwersalna_prędkość() > pojazdy[j + 1].Uniwersalna_prędkość())
                    {
                        var temp = pojazdy[j];
                        pojazdy[j] = pojazdy[j + 1];
                        pojazdy[j + 1] = temp;
                    }
                }
            }



            foreach (Pojazd pojazd in pojazdy)
            {
                Console.WriteLine(pojazd.ToString());
                Console.WriteLine(pojazd.Uniwersalna_prędkość());
                Console.WriteLine("----------------------------------------------------------------");
            }


            Console.WriteLine("Sorting only ground vehicles based on current speed,ascending");
            List<PojazdLadowy> Ląd = new List<PojazdLadowy>();
            foreach (Pojazd pojazd in pojazdy)
            {
                if (pojazd.środowisko == Środowisko.Ziemia)
                {
                    Ląd.Add((PojazdLadowy)pojazd);
                }
            }
            for (int i = 0; i < Ląd.Count; i++)
            {
                for (int j = 0; j < Ląd.Count - i - 1; j++)
                {
                    if (Ląd[j].Uniwersalna_prędkość() < Ląd[j + 1].Uniwersalna_prędkość())
                    {
                        var tmp = Ląd[j];
                        Ląd[j] = Ląd[j + 1];
                        Ląd[j + 1] = tmp;
                    }
                }
            }
            foreach (Pojazd pojazd in Ląd)
            {
                Console.WriteLine(pojazd.ToString());
                Console.WriteLine(pojazd.Uniwersalna_prędkość());
                Console.WriteLine("---------------------------------------");
            }

        }
    }
}